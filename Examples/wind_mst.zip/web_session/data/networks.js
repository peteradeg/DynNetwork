var networks = {"Peter LGA_1": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.1",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "Peter LGA_1",
    "name" : "Peter LGA_1",
    "SUID" : 79,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "138",
        "shared_name" : "time0_EAST GIPPSLAND SHIRE",
        "name" : "time4_EAST GIPPSLAND SHIRE",
        "SUID" : 138,
        "nsize" : 9.05144225436E9,
        "selected" : false,
        "nvaluefactor" : 95.6508285531
      },
      "position" : {
        "x" : 421.1772167502445,
        "y" : -411.2976339746258
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "137",
        "shared_name" : "time0_NILLUMBIK SHIRE",
        "name" : "time4_NILLUMBIK SHIRE",
        "SUID" : 137,
        "nsize" : 1.57383880808E10,
        "selected" : false,
        "nvaluefactor" : 89.2981328627
      },
      "position" : {
        "x" : 287.0407749886268,
        "y" : -306.3225279943066
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "136",
        "shared_name" : "time0_CENTRAL GOLDFIELDS SHIRE",
        "name" : "time4_CENTRAL GOLDFIELDS SHIRE",
        "SUID" : 136,
        "nsize" : 2.10747325805E10,
        "selected" : false,
        "nvaluefactor" : 90.5817208905
      },
      "position" : {
        "x" : -503.1831500521944,
        "y" : 69.63996960677453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "135",
        "shared_name" : "time0_MACEDON RANGES SHIRE",
        "name" : "time4_MACEDON RANGES SHIRE",
        "SUID" : 135,
        "nsize" : 2.26108033584E10,
        "selected" : false,
        "nvaluefactor" : 90.0210517615
      },
      "position" : {
        "x" : 8.98243726829239,
        "y" : 341.8195198914681
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "134",
        "shared_name" : "time0_MITCHELL SHIRE",
        "name" : "time4_MITCHELL SHIRE",
        "SUID" : 134,
        "nsize" : 2.37093687907E10,
        "selected" : false,
        "nvaluefactor" : 89.6578738937
      },
      "position" : {
        "x" : -207.48822115149284,
        "y" : -493.16834151857995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "133",
        "shared_name" : "time0_MORNINGTON PENINSULA SHIRE",
        "name" : "time4_MORNINGTON PENINSULA SHIRE",
        "SUID" : 133,
        "nsize" : 2.94052503423E10,
        "selected" : false,
        "nvaluefactor" : 91.6972276413
      },
      "position" : {
        "x" : 396.43507199907447,
        "y" : 622.7854313207372
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "132",
        "shared_name" : "time0_GANNAWARRA SHIRE",
        "name" : "time4_GANNAWARRA SHIRE",
        "SUID" : 132,
        "nsize" : 2.37973856121E10,
        "selected" : false,
        "nvaluefactor" : 93.677615541
      },
      "position" : {
        "x" : 31.98455896507289,
        "y" : -474.43930798857167
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "131",
        "shared_name" : "time0_GREATER SHEPPARTON CITY",
        "name" : "time4_GREATER SHEPPARTON CITY",
        "SUID" : 131,
        "nsize" : 2.11725140804E10,
        "selected" : false,
        "nvaluefactor" : 97.0031462791
      },
      "position" : {
        "x" : 322.40811169160287,
        "y" : -409.48415881185525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "130",
        "shared_name" : "time0_WELLINGTON SHIRE",
        "name" : "time4_WELLINGTON SHIRE",
        "SUID" : 130,
        "nsize" : 1.17384331994E10,
        "selected" : false,
        "nvaluefactor" : 89.4025002663
      },
      "position" : {
        "x" : 421.1772167502445,
        "y" : -411.2976339746258
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "129",
        "shared_name" : "time0_MURRINDINDI SHIRE",
        "name" : "time4_MURRINDINDI SHIRE",
        "SUID" : 129,
        "nsize" : 8.84979721014E9,
        "selected" : false,
        "nvaluefactor" : 89.64464145
      },
      "position" : {
        "x" : 287.0407749886268,
        "y" : -306.3225279943066
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "128",
        "shared_name" : "time0_ALPINE SHIRE",
        "name" : "time4_ALPINE SHIRE",
        "SUID" : 128,
        "nsize" : 4.73118652735E9,
        "selected" : false,
        "nvaluefactor" : 82.3344989267
      },
      "position" : {
        "x" : 332.6913026224864,
        "y" : 34.023830375862026
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "127",
        "shared_name" : "time0_WODONGA CITY",
        "name" : "time4_WODONGA CITY",
        "SUID" : 127,
        "nsize" : 6.01975666026E9,
        "selected" : false,
        "nvaluefactor" : 90.8947047893
      },
      "position" : {
        "x" : 332.6913026224864,
        "y" : 34.023830375862026
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "126",
        "shared_name" : "time0_PYRENEES SHIRE",
        "name" : "time4_PYRENEES SHIRE",
        "SUID" : 126,
        "nsize" : 2.1261155963E10,
        "selected" : false,
        "nvaluefactor" : 89.7722936103
      },
      "position" : {
        "x" : -503.1831500521944,
        "y" : 69.63996960677453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "125",
        "shared_name" : "time0_TOWONG SHIRE",
        "name" : "time4_TOWONG SHIRE",
        "SUID" : 125,
        "nsize" : 4.60048348313E9,
        "selected" : false,
        "nvaluefactor" : 84.594398964
      },
      "position" : {
        "x" : 332.6913026224864,
        "y" : 34.023830375862026
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "124",
        "shared_name" : "time0_BAW BAW SHIRE",
        "name" : "time4_BAW BAW SHIRE",
        "SUID" : 124,
        "nsize" : 1.21329980243E10,
        "selected" : false,
        "nvaluefactor" : 91.5567019935
      },
      "position" : {
        "x" : -417.82604306344564,
        "y" : -81.39601597536654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "123",
        "shared_name" : "time0_SOUTH GIPPSLAND SHIRE",
        "name" : "time4_SOUTH GIPPSLAND SHIRE",
        "SUID" : 123,
        "nsize" : 2.01925669967E10,
        "selected" : false,
        "nvaluefactor" : 92.4079679201
      },
      "position" : {
        "x" : 171.24645431480624,
        "y" : 425.68258375218215
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "122",
        "shared_name" : "time0_CARDINIA SHIRE",
        "name" : "time4_CARDINIA SHIRE",
        "SUID" : 122,
        "nsize" : 1.35485180947E10,
        "selected" : false,
        "nvaluefactor" : 89.7192634683
      },
      "position" : {
        "x" : -417.82604306344564,
        "y" : -81.39601597536654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "121",
        "shared_name" : "time0_MILDURA RURAL CITY",
        "name" : "time4_MILDURA RURAL CITY",
        "SUID" : 121,
        "nsize" : 2.34623996191E10,
        "selected" : false,
        "nvaluefactor" : 95.4703232374
      },
      "position" : {
        "x" : 528.986305923417,
        "y" : 476.48966377811445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "120",
        "shared_name" : "time0_LATROBE CITY",
        "name" : "time4_LATROBE CITY",
        "SUID" : 120,
        "nsize" : 1.53196848228E10,
        "selected" : false,
        "nvaluefactor" : 90.975871265
      },
      "position" : {
        "x" : -124.56649662949998,
        "y" : -386.61017257072945
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "119",
        "shared_name" : "time0_MOYNE SHIRE",
        "name" : "time4_MOYNE SHIRE",
        "SUID" : 119,
        "nsize" : 1.89980754866E10,
        "selected" : false,
        "nvaluefactor" : 93.9352078704
      },
      "position" : {
        "x" : 355.7468716110053,
        "y" : -110.54430470468513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "118",
        "shared_name" : "time0_MANSFIELD SHIRE",
        "name" : "time4_MANSFIELD SHIRE",
        "SUID" : 118,
        "nsize" : 8.62007603185E9,
        "selected" : false,
        "nvaluefactor" : 87.4041166499
      },
      "position" : {
        "x" : 332.6913026224864,
        "y" : 34.023830375862026
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "117",
        "shared_name" : "time0_ARARAT RURAL CITY",
        "name" : "time4_ARARAT RURAL CITY",
        "SUID" : 117,
        "nsize" : 2.19327520822E10,
        "selected" : false,
        "nvaluefactor" : 90.4264039615
      },
      "position" : {
        "x" : -503.1831500521944,
        "y" : 69.63996960677453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "116",
        "shared_name" : "time0_MOORABOOL SHIRE",
        "name" : "time4_MOORABOOL SHIRE",
        "SUID" : 116,
        "nsize" : 1.78268909473E10,
        "selected" : false,
        "nvaluefactor" : 89.3374654509
      },
      "position" : {
        "x" : -295.33857597012246,
        "y" : -34.1923841364863
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "115",
        "shared_name" : "time0_CAMPASPE SHIRE",
        "name" : "time4_CAMPASPE SHIRE",
        "SUID" : 115,
        "nsize" : 2.40422170908E10,
        "selected" : false,
        "nvaluefactor" : 97.9076258991
      },
      "position" : {
        "x" : 317.94124292737,
        "y" : -228.69973238344707
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "114",
        "shared_name" : "time0_CORANGAMITE SHIRE",
        "name" : "time4_CORANGAMITE SHIRE",
        "SUID" : 114,
        "nsize" : 1.80971644444E10,
        "selected" : false,
        "nvaluefactor" : 91.8965122955
      },
      "position" : {
        "x" : 355.7468716110053,
        "y" : -110.54430470468513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "113",
        "shared_name" : "time0_SWAN HILL RURAL CITY",
        "name" : "time4_SWAN HILL RURAL CITY",
        "SUID" : 113,
        "nsize" : 2.28482449074E10,
        "selected" : false,
        "nvaluefactor" : 96.778108422
      },
      "position" : {
        "x" : 563.7991105659601,
        "y" : 199.61263637620334
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "112",
        "shared_name" : "time0_COLAC OTWAY SHIRE",
        "name" : "time4_COLAC OTWAY SHIRE",
        "SUID" : 112,
        "nsize" : 1.77172609871E10,
        "selected" : false,
        "nvaluefactor" : 90.7123802821
      },
      "position" : {
        "x" : 355.7468716110053,
        "y" : -110.54430470468513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "111",
        "shared_name" : "time0_GLENELG SHIRE",
        "name" : "time4_GLENELG SHIRE",
        "SUID" : 111,
        "nsize" : 2.16118926718E10,
        "selected" : false,
        "nvaluefactor" : 91.8420749241
      },
      "position" : {
        "x" : 22.125777007444988,
        "y" : 724.0831687861855
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "110",
        "shared_name" : "time0_YARRA RANGES SHIRE",
        "name" : "time4_YARRA RANGES SHIRE",
        "SUID" : 110,
        "nsize" : 9.74860863342E9,
        "selected" : false,
        "nvaluefactor" : 91.2505951198
      },
      "position" : {
        "x" : -417.82604306344564,
        "y" : -81.39601597536654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "109",
        "shared_name" : "time0_HEPBURN SHIRE",
        "name" : "time4_HEPBURN SHIRE",
        "SUID" : 109,
        "nsize" : 2.51387765603E10,
        "selected" : false,
        "nvaluefactor" : 91.7895800958
      },
      "position" : {
        "x" : -503.1831500521944,
        "y" : 69.63996960677453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "108",
        "shared_name" : "time0_NORTHERN GRAMPIANS SHIRE",
        "name" : "time4_NORTHERN GRAMPIANS SHIRE",
        "SUID" : 108,
        "nsize" : 2.58124313249E10,
        "selected" : false,
        "nvaluefactor" : 92.955992524
      },
      "position" : {
        "x" : -503.1831500521944,
        "y" : 69.63996960677453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "107",
        "shared_name" : "time0_WEST WIMMERA SHIRE",
        "name" : "time4_WEST WIMMERA SHIRE",
        "SUID" : 107,
        "nsize" : 2.61275518705E10,
        "selected" : false,
        "nvaluefactor" : 94.4359370962
      },
      "position" : {
        "x" : -497.7063923956886,
        "y" : 301.4824577026555
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "106",
        "shared_name" : "time0_BULOKE SHIRE",
        "name" : "time4_BULOKE SHIRE",
        "SUID" : 106,
        "nsize" : 2.56164830669E10,
        "selected" : false,
        "nvaluefactor" : 93.7262472441
      },
      "position" : {
        "x" : -303.0105886450861,
        "y" : -30.888759910418784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "105",
        "shared_name" : "time0_GREATER BENDIGO CITY",
        "name" : "time4_GREATER BENDIGO CITY",
        "SUID" : 105,
        "nsize" : 2.42023025129E10,
        "selected" : false,
        "nvaluefactor" : 94.3208699112
      },
      "position" : {
        "x" : -63.20275374210914,
        "y" : -131.59861763832964
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "104",
        "shared_name" : "time0_STRATHBOGIE SHIRE",
        "name" : "time4_STRATHBOGIE SHIRE",
        "SUID" : 104,
        "nsize" : 2.10405193478E10,
        "selected" : false,
        "nvaluefactor" : 95.742257903
      },
      "position" : {
        "x" : 322.40811169160287,
        "y" : -409.48415881185525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "103",
        "shared_name" : "time0_WANGARATTA RURAL CITY",
        "name" : "time4_WANGARATTA RURAL CITY",
        "SUID" : 103,
        "nsize" : 8.30871149484E9,
        "selected" : false,
        "nvaluefactor" : 90.3557414713
      },
      "position" : {
        "x" : 322.40811169160287,
        "y" : -409.48415881185525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "102",
        "shared_name" : "time0_GOLDEN PLAINS SHIRE",
        "name" : "time4_GOLDEN PLAINS SHIRE",
        "SUID" : 102,
        "nsize" : 2.02589214176E10,
        "selected" : false,
        "nvaluefactor" : 90.4422220303
      },
      "position" : {
        "x" : -73.25952185888035,
        "y" : -90.22628703287202
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "101",
        "shared_name" : "time0_MOUNT ALEXANDER SHIRE",
        "name" : "time4_MOUNT ALEXANDER SHIRE",
        "SUID" : 101,
        "nsize" : 2.34503857847E10,
        "selected" : false,
        "nvaluefactor" : 92.4539850354
      },
      "position" : {
        "x" : -178.0664165792249,
        "y" : 410.00834166296534
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "100",
        "shared_name" : "time0_SURF COAST SHIRE",
        "name" : "time4_SURF COAST SHIRE",
        "SUID" : 100,
        "nsize" : 1.8272887568E10,
        "selected" : false,
        "nvaluefactor" : 89.371815674
      },
      "position" : {
        "x" : -417.82604306344564,
        "y" : -81.39601597536654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "99",
        "shared_name" : "time0_BENALLA RURAL CITY",
        "name" : "time4_BENALLA RURAL CITY",
        "SUID" : 99,
        "nsize" : 1.69735485641E10,
        "selected" : false,
        "nvaluefactor" : 95.3165514953
      },
      "position" : {
        "x" : 322.40811169160287,
        "y" : -409.48415881185525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "98",
        "shared_name" : "time0_BASS COAST SHIRE",
        "name" : "time4_BASS COAST SHIRE",
        "SUID" : 98,
        "nsize" : 2.55609958332E10,
        "selected" : false,
        "nvaluefactor" : 92.4888749557
      },
      "position" : {
        "x" : 207.35939372921246,
        "y" : 688.2859780068452
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "97",
        "shared_name" : "time0_MOIRA SHIRE",
        "name" : "time4_MOIRA SHIRE",
        "SUID" : 97,
        "nsize" : 2.13613746896E10,
        "selected" : false,
        "nvaluefactor" : 98.2732331336
      },
      "position" : {
        "x" : 322.40811169160287,
        "y" : -409.48415881185525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "96",
        "shared_name" : "time0_YARRIAMBIACK SHIRE",
        "name" : "time4_YARRIAMBIACK SHIRE",
        "SUID" : 96,
        "nsize" : 2.66048618992E10,
        "selected" : false,
        "nvaluefactor" : 94.942251262
      },
      "position" : {
        "x" : -303.0105886450861,
        "y" : -30.888759910418784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "95",
        "shared_name" : "time0_INDIGO SHIRE",
        "name" : "time4_INDIGO SHIRE",
        "SUID" : 95,
        "nsize" : 9.05533421112E9,
        "selected" : false,
        "nvaluefactor" : 93.7513794882
      },
      "position" : {
        "x" : 100.35947975152828,
        "y" : -117.71689990664426
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "94",
        "shared_name" : "time0_HINDMARSH SHIRE",
        "name" : "time4_HINDMARSH SHIRE",
        "SUID" : 94,
        "nsize" : 2.58194491054E10,
        "selected" : false,
        "nvaluefactor" : 94.8507534346
      },
      "position" : {
        "x" : -331.8114888755459,
        "y" : 530.036629356078
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "93",
        "shared_name" : "time0_SOUTHERN GRAMPIANS SHIRE",
        "name" : "time4_SOUTHERN GRAMPIANS SHIRE",
        "SUID" : 93,
        "nsize" : 2.1501898984E10,
        "selected" : false,
        "nvaluefactor" : 92.1032930486
      },
      "position" : {
        "x" : -235.44497424319476,
        "y" : 610.6474707805746
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "92",
        "shared_name" : "time0_LODDON SHIRE",
        "name" : "time4_LODDON SHIRE",
        "SUID" : 92,
        "nsize" : 2.37364982832E10,
        "selected" : false,
        "nvaluefactor" : 93.3627137695
      },
      "position" : {
        "x" : -113.2527664176221,
        "y" : -54.79274775360893
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "91",
        "shared_name" : "time0_BALLARAT CITY",
        "name" : "time4_BALLARAT CITY",
        "SUID" : 91,
        "nsize" : 2.34721070792E10,
        "selected" : false,
        "nvaluefactor" : 91.2770657322
      },
      "position" : {
        "x" : -720.3639712579079,
        "y" : 206.93290281346827
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "90",
        "shared_name" : "time0_HORSHAM RURAL CITY",
        "name" : "time4_HORSHAM RURAL CITY",
        "SUID" : 90,
        "nsize" : 2.49455248106E10,
        "selected" : false,
        "nvaluefactor" : 94.258396955
      },
      "position" : {
        "x" : -497.7063923956886,
        "y" : 301.4824577026555
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "89",
        "shared_name" : "time0_WARRNAMBOOL CITY",
        "name" : "time4_WARRNAMBOOL CITY",
        "SUID" : 89,
        "nsize" : 2.11235460816E10,
        "selected" : false,
        "nvaluefactor" : 92.4510328909
      },
      "position" : {
        "x" : 355.7468716110053,
        "y" : -110.54430470468513
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "383",
        "source" : "134",
        "target" : "137",
        "shared_name" : "edge_MITCHELL SHIRE_NILLUMBIK SHIRE_time_4",
        "name" : "edge_MITCHELL SHIRE_NILLUMBIK SHIRE_time_4",
        "SUID" : 383,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "382",
        "source" : "134",
        "target" : "135",
        "shared_name" : "edge_MITCHELL SHIRE_MACEDON RANGES SHIRE_time_4",
        "name" : "edge_MITCHELL SHIRE_MACEDON RANGES SHIRE_time_4",
        "SUID" : 382,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "334",
        "source" : "134",
        "target" : "137",
        "shared_name" : "edge_MITCHELL SHIRE_NILLUMBIK SHIRE_time_3",
        "name" : "edge_MITCHELL SHIRE_NILLUMBIK SHIRE_time_3",
        "SUID" : 334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "333",
        "source" : "134",
        "target" : "135",
        "shared_name" : "edge_MITCHELL SHIRE_MACEDON RANGES SHIRE_time_3",
        "name" : "edge_MITCHELL SHIRE_MACEDON RANGES SHIRE_time_3",
        "SUID" : 333,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "source" : "134",
        "target" : "137",
        "shared_name" : "edge_MITCHELL SHIRE_NILLUMBIK SHIRE_time_2",
        "name" : "edge_MITCHELL SHIRE_NILLUMBIK SHIRE_time_2",
        "SUID" : 285,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "284",
        "source" : "134",
        "target" : "135",
        "shared_name" : "edge_MITCHELL SHIRE_MACEDON RANGES SHIRE_time_2",
        "name" : "edge_MITCHELL SHIRE_MACEDON RANGES SHIRE_time_2",
        "SUID" : 284,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "source" : "134",
        "target" : "137",
        "shared_name" : "edge_MITCHELL SHIRE_NILLUMBIK SHIRE_time_1",
        "name" : "edge_MITCHELL SHIRE_NILLUMBIK SHIRE_time_1",
        "SUID" : 236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "235",
        "source" : "134",
        "target" : "135",
        "shared_name" : "edge_MITCHELL SHIRE_MACEDON RANGES SHIRE_time_1",
        "name" : "edge_MITCHELL SHIRE_MACEDON RANGES SHIRE_time_1",
        "SUID" : 235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "187",
        "source" : "134",
        "target" : "137",
        "shared_name" : "edge_MITCHELL SHIRE_NILLUMBIK SHIRE_time_0",
        "distance" : 0.57420710897,
        "name" : "edge_MITCHELL SHIRE_NILLUMBIK SHIRE_time_0",
        "weight" : 0.835143098004,
        "SUID" : 187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "186",
        "source" : "134",
        "target" : "135",
        "shared_name" : "edge_MITCHELL SHIRE_MACEDON RANGES SHIRE_time_0",
        "distance" : 0.498679377297,
        "name" : "edge_MITCHELL SHIRE_MACEDON RANGES SHIRE_time_0",
        "weight" : 0.875659439329,
        "SUID" : 186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "381",
        "source" : "130",
        "target" : "138",
        "shared_name" : "edge_WELLINGTON SHIRE_EAST GIPPSLAND SHIRE_time_4",
        "name" : "edge_WELLINGTON SHIRE_EAST GIPPSLAND SHIRE_time_4",
        "SUID" : 381,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "source" : "130",
        "target" : "138",
        "shared_name" : "edge_WELLINGTON SHIRE_EAST GIPPSLAND SHIRE_time_3",
        "name" : "edge_WELLINGTON SHIRE_EAST GIPPSLAND SHIRE_time_3",
        "SUID" : 332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "283",
        "source" : "130",
        "target" : "138",
        "shared_name" : "edge_WELLINGTON SHIRE_EAST GIPPSLAND SHIRE_time_2",
        "name" : "edge_WELLINGTON SHIRE_EAST GIPPSLAND SHIRE_time_2",
        "SUID" : 283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "source" : "130",
        "target" : "138",
        "shared_name" : "edge_WELLINGTON SHIRE_EAST GIPPSLAND SHIRE_time_0",
        "distance" : 0.838451333176,
        "name" : "edge_WELLINGTON SHIRE_EAST GIPPSLAND SHIRE_time_0",
        "weight" : 0.648499680947,
        "SUID" : 185,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "source" : "129",
        "target" : "137",
        "shared_name" : "edge_MURRINDINDI SHIRE_NILLUMBIK SHIRE_time_1",
        "name" : "edge_MURRINDINDI SHIRE_NILLUMBIK SHIRE_time_1",
        "SUID" : 234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "184",
        "source" : "129",
        "target" : "137",
        "shared_name" : "edge_MURRINDINDI SHIRE_NILLUMBIK SHIRE_time_0",
        "distance" : 0.59152640192,
        "name" : "edge_MURRINDINDI SHIRE_NILLUMBIK SHIRE_time_0",
        "weight" : 0.825048257916,
        "SUID" : 184,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "380",
        "source" : "126",
        "target" : "136",
        "shared_name" : "edge_PYRENEES SHIRE_CENTRAL GOLDFIELDS SHIRE_time_4",
        "name" : "edge_PYRENEES SHIRE_CENTRAL GOLDFIELDS SHIRE_time_4",
        "SUID" : 380,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "331",
        "source" : "126",
        "target" : "136",
        "shared_name" : "edge_PYRENEES SHIRE_CENTRAL GOLDFIELDS SHIRE_time_3",
        "name" : "edge_PYRENEES SHIRE_CENTRAL GOLDFIELDS SHIRE_time_3",
        "SUID" : 331,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "282",
        "source" : "126",
        "target" : "136",
        "shared_name" : "edge_PYRENEES SHIRE_CENTRAL GOLDFIELDS SHIRE_time_2",
        "name" : "edge_PYRENEES SHIRE_CENTRAL GOLDFIELDS SHIRE_time_2",
        "SUID" : 282,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "source" : "126",
        "target" : "136",
        "shared_name" : "edge_PYRENEES SHIRE_CENTRAL GOLDFIELDS SHIRE_time_1",
        "name" : "edge_PYRENEES SHIRE_CENTRAL GOLDFIELDS SHIRE_time_1",
        "SUID" : 233,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "source" : "126",
        "target" : "136",
        "shared_name" : "edge_PYRENEES SHIRE_CENTRAL GOLDFIELDS SHIRE_time_0",
        "distance" : 0.336923428852,
        "name" : "edge_PYRENEES SHIRE_CENTRAL GOLDFIELDS SHIRE_time_0",
        "weight" : 0.943241301545,
        "SUID" : 183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "source" : "125",
        "target" : "127",
        "shared_name" : "edge_TOWONG SHIRE_WODONGA CITY_time_4",
        "name" : "edge_TOWONG SHIRE_WODONGA CITY_time_4",
        "SUID" : 379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "378",
        "source" : "125",
        "target" : "128",
        "shared_name" : "edge_TOWONG SHIRE_ALPINE SHIRE_time_4",
        "name" : "edge_TOWONG SHIRE_ALPINE SHIRE_time_4",
        "SUID" : 378,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "330",
        "source" : "125",
        "target" : "127",
        "shared_name" : "edge_TOWONG SHIRE_WODONGA CITY_time_3",
        "name" : "edge_TOWONG SHIRE_WODONGA CITY_time_3",
        "SUID" : 330,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "329",
        "source" : "125",
        "target" : "128",
        "shared_name" : "edge_TOWONG SHIRE_ALPINE SHIRE_time_3",
        "name" : "edge_TOWONG SHIRE_ALPINE SHIRE_time_3",
        "SUID" : 329,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "source" : "125",
        "target" : "127",
        "shared_name" : "edge_TOWONG SHIRE_WODONGA CITY_time_2",
        "name" : "edge_TOWONG SHIRE_WODONGA CITY_time_2",
        "SUID" : 281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "232",
        "source" : "125",
        "target" : "127",
        "shared_name" : "edge_TOWONG SHIRE_WODONGA CITY_time_1",
        "name" : "edge_TOWONG SHIRE_WODONGA CITY_time_1",
        "SUID" : 232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "231",
        "source" : "125",
        "target" : "128",
        "shared_name" : "edge_TOWONG SHIRE_ALPINE SHIRE_time_1",
        "name" : "edge_TOWONG SHIRE_ALPINE SHIRE_time_1",
        "SUID" : 231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "182",
        "source" : "125",
        "target" : "127",
        "shared_name" : "edge_TOWONG SHIRE_WODONGA CITY_time_0",
        "distance" : 0.473893790088,
        "name" : "edge_TOWONG SHIRE_WODONGA CITY_time_0",
        "weight" : 0.887712337858,
        "SUID" : 182,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "181",
        "source" : "125",
        "target" : "128",
        "shared_name" : "edge_TOWONG SHIRE_ALPINE SHIRE_time_0",
        "distance" : 0.538018994169,
        "name" : "edge_TOWONG SHIRE_ALPINE SHIRE_time_0",
        "weight" : 0.855267780956,
        "SUID" : 181,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "328",
        "source" : "122",
        "target" : "124",
        "shared_name" : "edge_CARDINIA SHIRE_BAW BAW SHIRE_time_3",
        "name" : "edge_CARDINIA SHIRE_BAW BAW SHIRE_time_3",
        "SUID" : 328,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "280",
        "source" : "122",
        "target" : "124",
        "shared_name" : "edge_CARDINIA SHIRE_BAW BAW SHIRE_time_2",
        "name" : "edge_CARDINIA SHIRE_BAW BAW SHIRE_time_2",
        "SUID" : 280,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "source" : "122",
        "target" : "124",
        "shared_name" : "edge_CARDINIA SHIRE_BAW BAW SHIRE_time_1",
        "name" : "edge_CARDINIA SHIRE_BAW BAW SHIRE_time_1",
        "SUID" : 230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "180",
        "source" : "122",
        "target" : "124",
        "shared_name" : "edge_CARDINIA SHIRE_BAW BAW SHIRE_time_0",
        "distance" : 0.529910394816,
        "name" : "edge_CARDINIA SHIRE_BAW BAW SHIRE_time_0",
        "weight" : 0.859597486733,
        "SUID" : 180,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "source" : "120",
        "target" : "123",
        "shared_name" : "edge_LATROBE CITY_SOUTH GIPPSLAND SHIRE_time_4",
        "name" : "edge_LATROBE CITY_SOUTH GIPPSLAND SHIRE_time_4",
        "SUID" : 377,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "376",
        "source" : "120",
        "target" : "130",
        "shared_name" : "edge_LATROBE CITY_WELLINGTON SHIRE_time_4",
        "name" : "edge_LATROBE CITY_WELLINGTON SHIRE_time_4",
        "SUID" : 376,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "source" : "120",
        "target" : "124",
        "shared_name" : "edge_LATROBE CITY_BAW BAW SHIRE_time_4",
        "name" : "edge_LATROBE CITY_BAW BAW SHIRE_time_4",
        "SUID" : 375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "327",
        "source" : "120",
        "target" : "123",
        "shared_name" : "edge_LATROBE CITY_SOUTH GIPPSLAND SHIRE_time_3",
        "name" : "edge_LATROBE CITY_SOUTH GIPPSLAND SHIRE_time_3",
        "SUID" : 327,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "source" : "120",
        "target" : "130",
        "shared_name" : "edge_LATROBE CITY_WELLINGTON SHIRE_time_3",
        "name" : "edge_LATROBE CITY_WELLINGTON SHIRE_time_3",
        "SUID" : 326,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "325",
        "source" : "120",
        "target" : "124",
        "shared_name" : "edge_LATROBE CITY_BAW BAW SHIRE_time_3",
        "name" : "edge_LATROBE CITY_BAW BAW SHIRE_time_3",
        "SUID" : 325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "279",
        "source" : "120",
        "target" : "123",
        "shared_name" : "edge_LATROBE CITY_SOUTH GIPPSLAND SHIRE_time_2",
        "name" : "edge_LATROBE CITY_SOUTH GIPPSLAND SHIRE_time_2",
        "SUID" : 279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "source" : "120",
        "target" : "130",
        "shared_name" : "edge_LATROBE CITY_WELLINGTON SHIRE_time_2",
        "name" : "edge_LATROBE CITY_WELLINGTON SHIRE_time_2",
        "SUID" : 278,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "source" : "120",
        "target" : "124",
        "shared_name" : "edge_LATROBE CITY_BAW BAW SHIRE_time_2",
        "name" : "edge_LATROBE CITY_BAW BAW SHIRE_time_2",
        "SUID" : 277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "229",
        "source" : "120",
        "target" : "123",
        "shared_name" : "edge_LATROBE CITY_SOUTH GIPPSLAND SHIRE_time_1",
        "name" : "edge_LATROBE CITY_SOUTH GIPPSLAND SHIRE_time_1",
        "SUID" : 229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "source" : "120",
        "target" : "130",
        "shared_name" : "edge_LATROBE CITY_WELLINGTON SHIRE_time_1",
        "name" : "edge_LATROBE CITY_WELLINGTON SHIRE_time_1",
        "SUID" : 228,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "227",
        "source" : "120",
        "target" : "124",
        "shared_name" : "edge_LATROBE CITY_BAW BAW SHIRE_time_1",
        "name" : "edge_LATROBE CITY_BAW BAW SHIRE_time_1",
        "SUID" : 227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "179",
        "source" : "120",
        "target" : "123",
        "shared_name" : "edge_LATROBE CITY_SOUTH GIPPSLAND SHIRE_time_0",
        "distance" : 0.391589733845,
        "name" : "edge_LATROBE CITY_SOUTH GIPPSLAND SHIRE_time_0",
        "weight" : 0.923328740173,
        "SUID" : 179,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "178",
        "source" : "120",
        "target" : "130",
        "shared_name" : "edge_LATROBE CITY_WELLINGTON SHIRE_time_0",
        "distance" : 0.452452734779,
        "name" : "edge_LATROBE CITY_WELLINGTON SHIRE_time_0",
        "weight" : 0.897643261395,
        "SUID" : 178,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177",
        "source" : "120",
        "target" : "124",
        "shared_name" : "edge_LATROBE CITY_BAW BAW SHIRE_time_0",
        "distance" : 0.326585250779,
        "name" : "edge_LATROBE CITY_BAW BAW SHIRE_time_0",
        "weight" : 0.946671036987,
        "SUID" : 177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "374",
        "source" : "118",
        "target" : "128",
        "shared_name" : "edge_MANSFIELD SHIRE_ALPINE SHIRE_time_4",
        "name" : "edge_MANSFIELD SHIRE_ALPINE SHIRE_time_4",
        "SUID" : 374,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "324",
        "source" : "118",
        "target" : "129",
        "shared_name" : "edge_MANSFIELD SHIRE_MURRINDINDI SHIRE_time_3",
        "name" : "edge_MANSFIELD SHIRE_MURRINDINDI SHIRE_time_3",
        "SUID" : 324,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "276",
        "source" : "118",
        "target" : "129",
        "shared_name" : "edge_MANSFIELD SHIRE_MURRINDINDI SHIRE_time_2",
        "name" : "edge_MANSFIELD SHIRE_MURRINDINDI SHIRE_time_2",
        "SUID" : 276,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "source" : "118",
        "target" : "128",
        "shared_name" : "edge_MANSFIELD SHIRE_ALPINE SHIRE_time_2",
        "name" : "edge_MANSFIELD SHIRE_ALPINE SHIRE_time_2",
        "SUID" : 275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "226",
        "source" : "118",
        "target" : "138",
        "shared_name" : "edge_MANSFIELD SHIRE_EAST GIPPSLAND SHIRE_time_1",
        "name" : "edge_MANSFIELD SHIRE_EAST GIPPSLAND SHIRE_time_1",
        "SUID" : 226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "225",
        "source" : "118",
        "target" : "129",
        "shared_name" : "edge_MANSFIELD SHIRE_MURRINDINDI SHIRE_time_1",
        "name" : "edge_MANSFIELD SHIRE_MURRINDINDI SHIRE_time_1",
        "SUID" : 225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176",
        "source" : "118",
        "target" : "128",
        "shared_name" : "edge_MANSFIELD SHIRE_ALPINE SHIRE_time_0",
        "distance" : 0.566352817471,
        "name" : "edge_MANSFIELD SHIRE_ALPINE SHIRE_time_0",
        "weight" : 0.839622243071,
        "SUID" : 176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "373",
        "source" : "117",
        "target" : "119",
        "shared_name" : "edge_ARARAT RURAL CITY_MOYNE SHIRE_time_4",
        "name" : "edge_ARARAT RURAL CITY_MOYNE SHIRE_time_4",
        "SUID" : 373,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "175",
        "source" : "117",
        "target" : "126",
        "shared_name" : "edge_ARARAT RURAL CITY_PYRENEES SHIRE_time_0",
        "distance" : 0.505979989243,
        "name" : "edge_ARARAT RURAL CITY_PYRENEES SHIRE_time_0",
        "weight" : 0.871992125243,
        "SUID" : 175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "323",
        "source" : "116",
        "target" : "122",
        "shared_name" : "edge_MOORABOOL SHIRE_CARDINIA SHIRE_time_3",
        "name" : "edge_MOORABOOL SHIRE_CARDINIA SHIRE_time_3",
        "SUID" : 323,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "322",
        "source" : "115",
        "target" : "131",
        "shared_name" : "edge_CAMPASPE SHIRE_GREATER SHEPPARTON CITY_time_3",
        "name" : "edge_CAMPASPE SHIRE_GREATER SHEPPARTON CITY_time_3",
        "SUID" : 322,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "274",
        "source" : "115",
        "target" : "131",
        "shared_name" : "edge_CAMPASPE SHIRE_GREATER SHEPPARTON CITY_time_2",
        "name" : "edge_CAMPASPE SHIRE_GREATER SHEPPARTON CITY_time_2",
        "SUID" : 274,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "224",
        "source" : "115",
        "target" : "131",
        "shared_name" : "edge_CAMPASPE SHIRE_GREATER SHEPPARTON CITY_time_1",
        "name" : "edge_CAMPASPE SHIRE_GREATER SHEPPARTON CITY_time_1",
        "SUID" : 224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "174",
        "source" : "115",
        "target" : "131",
        "shared_name" : "edge_CAMPASPE SHIRE_GREATER SHEPPARTON CITY_time_0",
        "distance" : 0.543262285221,
        "name" : "edge_CAMPASPE SHIRE_GREATER SHEPPARTON CITY_time_0",
        "weight" : 0.852433044728,
        "SUID" : 174,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "173",
        "source" : "115",
        "target" : "132",
        "shared_name" : "edge_CAMPASPE SHIRE_GANNAWARRA SHIRE_time_0",
        "distance" : 0.531270502433,
        "name" : "edge_CAMPASPE SHIRE_GANNAWARRA SHIRE_time_0",
        "weight" : 0.858875826622,
        "SUID" : 173,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "372",
        "source" : "114",
        "target" : "119",
        "shared_name" : "edge_CORANGAMITE SHIRE_MOYNE SHIRE_time_4",
        "name" : "edge_CORANGAMITE SHIRE_MOYNE SHIRE_time_4",
        "SUID" : 372,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "321",
        "source" : "114",
        "target" : "119",
        "shared_name" : "edge_CORANGAMITE SHIRE_MOYNE SHIRE_time_3",
        "name" : "edge_CORANGAMITE SHIRE_MOYNE SHIRE_time_3",
        "SUID" : 321,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "273",
        "source" : "114",
        "target" : "119",
        "shared_name" : "edge_CORANGAMITE SHIRE_MOYNE SHIRE_time_2",
        "name" : "edge_CORANGAMITE SHIRE_MOYNE SHIRE_time_2",
        "SUID" : 273,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "223",
        "source" : "114",
        "target" : "119",
        "shared_name" : "edge_CORANGAMITE SHIRE_MOYNE SHIRE_time_1",
        "name" : "edge_CORANGAMITE SHIRE_MOYNE SHIRE_time_1",
        "SUID" : 223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "172",
        "source" : "114",
        "target" : "119",
        "shared_name" : "edge_CORANGAMITE SHIRE_MOYNE SHIRE_time_0",
        "distance" : 0.4490444894,
        "name" : "edge_CORANGAMITE SHIRE_MOYNE SHIRE_time_0",
        "weight" : 0.89917952327,
        "SUID" : 172,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "source" : "113",
        "target" : "132",
        "shared_name" : "edge_SWAN HILL RURAL CITY_GANNAWARRA SHIRE_time_4",
        "name" : "edge_SWAN HILL RURAL CITY_GANNAWARRA SHIRE_time_4",
        "SUID" : 371,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "source" : "113",
        "target" : "132",
        "shared_name" : "edge_SWAN HILL RURAL CITY_GANNAWARRA SHIRE_time_3",
        "name" : "edge_SWAN HILL RURAL CITY_GANNAWARRA SHIRE_time_3",
        "SUID" : 320,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "source" : "113",
        "target" : "132",
        "shared_name" : "edge_SWAN HILL RURAL CITY_GANNAWARRA SHIRE_time_2",
        "name" : "edge_SWAN HILL RURAL CITY_GANNAWARRA SHIRE_time_2",
        "SUID" : 272,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "271",
        "source" : "113",
        "target" : "121",
        "shared_name" : "edge_SWAN HILL RURAL CITY_MILDURA RURAL CITY_time_2",
        "name" : "edge_SWAN HILL RURAL CITY_MILDURA RURAL CITY_time_2",
        "SUID" : 271,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "222",
        "source" : "113",
        "target" : "132",
        "shared_name" : "edge_SWAN HILL RURAL CITY_GANNAWARRA SHIRE_time_1",
        "name" : "edge_SWAN HILL RURAL CITY_GANNAWARRA SHIRE_time_1",
        "SUID" : 222,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "171",
        "source" : "113",
        "target" : "121",
        "shared_name" : "edge_SWAN HILL RURAL CITY_MILDURA RURAL CITY_time_0",
        "distance" : 0.449166196982,
        "name" : "edge_SWAN HILL RURAL CITY_MILDURA RURAL CITY_time_0",
        "weight" : 0.899124863745,
        "SUID" : 171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "170",
        "source" : "113",
        "target" : "132",
        "shared_name" : "edge_SWAN HILL RURAL CITY_GANNAWARRA SHIRE_time_0",
        "distance" : 0.460113344765,
        "name" : "edge_SWAN HILL RURAL CITY_GANNAWARRA SHIRE_time_0",
        "weight" : 0.894147854985,
        "SUID" : 170,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "370",
        "source" : "112",
        "target" : "114",
        "shared_name" : "edge_COLAC OTWAY SHIRE_CORANGAMITE SHIRE_time_4",
        "name" : "edge_COLAC OTWAY SHIRE_CORANGAMITE SHIRE_time_4",
        "SUID" : 370,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "319",
        "source" : "112",
        "target" : "114",
        "shared_name" : "edge_COLAC OTWAY SHIRE_CORANGAMITE SHIRE_time_3",
        "name" : "edge_COLAC OTWAY SHIRE_CORANGAMITE SHIRE_time_3",
        "SUID" : 319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "270",
        "source" : "112",
        "target" : "114",
        "shared_name" : "edge_COLAC OTWAY SHIRE_CORANGAMITE SHIRE_time_2",
        "name" : "edge_COLAC OTWAY SHIRE_CORANGAMITE SHIRE_time_2",
        "SUID" : 270,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "221",
        "source" : "112",
        "target" : "114",
        "shared_name" : "edge_COLAC OTWAY SHIRE_CORANGAMITE SHIRE_time_1",
        "name" : "edge_COLAC OTWAY SHIRE_CORANGAMITE SHIRE_time_1",
        "SUID" : 221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "169",
        "source" : "112",
        "target" : "114",
        "shared_name" : "edge_COLAC OTWAY SHIRE_CORANGAMITE SHIRE_time_0",
        "distance" : 0.296644655981,
        "name" : "edge_COLAC OTWAY SHIRE_CORANGAMITE SHIRE_time_0",
        "weight" : 0.956000974039,
        "SUID" : 169,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "318",
        "source" : "111",
        "target" : "119",
        "shared_name" : "edge_GLENELG SHIRE_MOYNE SHIRE_time_3",
        "name" : "edge_GLENELG SHIRE_MOYNE SHIRE_time_3",
        "SUID" : 318,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "269",
        "source" : "111",
        "target" : "119",
        "shared_name" : "edge_GLENELG SHIRE_MOYNE SHIRE_time_2",
        "name" : "edge_GLENELG SHIRE_MOYNE SHIRE_time_2",
        "SUID" : 269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "369",
        "source" : "110",
        "target" : "122",
        "shared_name" : "edge_YARRA RANGES SHIRE_CARDINIA SHIRE_time_4",
        "name" : "edge_YARRA RANGES SHIRE_CARDINIA SHIRE_time_4",
        "SUID" : 369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "317",
        "source" : "110",
        "target" : "122",
        "shared_name" : "edge_YARRA RANGES SHIRE_CARDINIA SHIRE_time_3",
        "name" : "edge_YARRA RANGES SHIRE_CARDINIA SHIRE_time_3",
        "SUID" : 317,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "source" : "110",
        "target" : "122",
        "shared_name" : "edge_YARRA RANGES SHIRE_CARDINIA SHIRE_time_2",
        "name" : "edge_YARRA RANGES SHIRE_CARDINIA SHIRE_time_2",
        "SUID" : 268,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "220",
        "source" : "110",
        "target" : "116",
        "shared_name" : "edge_YARRA RANGES SHIRE_MOORABOOL SHIRE_time_1",
        "name" : "edge_YARRA RANGES SHIRE_MOORABOOL SHIRE_time_1",
        "SUID" : 220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "219",
        "source" : "110",
        "target" : "122",
        "shared_name" : "edge_YARRA RANGES SHIRE_CARDINIA SHIRE_time_1",
        "name" : "edge_YARRA RANGES SHIRE_CARDINIA SHIRE_time_1",
        "SUID" : 219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "168",
        "source" : "110",
        "target" : "122",
        "shared_name" : "edge_YARRA RANGES SHIRE_CARDINIA SHIRE_time_0",
        "distance" : 0.528690576274,
        "name" : "edge_YARRA RANGES SHIRE_CARDINIA SHIRE_time_0",
        "weight" : 0.86024313728,
        "SUID" : 168,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "source" : "109",
        "target" : "135",
        "shared_name" : "edge_HEPBURN SHIRE_MACEDON RANGES SHIRE_time_4",
        "name" : "edge_HEPBURN SHIRE_MACEDON RANGES SHIRE_time_4",
        "SUID" : 368,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "367",
        "source" : "109",
        "target" : "136",
        "shared_name" : "edge_HEPBURN SHIRE_CENTRAL GOLDFIELDS SHIRE_time_4",
        "name" : "edge_HEPBURN SHIRE_CENTRAL GOLDFIELDS SHIRE_time_4",
        "SUID" : 367,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "316",
        "source" : "109",
        "target" : "135",
        "shared_name" : "edge_HEPBURN SHIRE_MACEDON RANGES SHIRE_time_3",
        "name" : "edge_HEPBURN SHIRE_MACEDON RANGES SHIRE_time_3",
        "SUID" : 316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "315",
        "source" : "109",
        "target" : "136",
        "shared_name" : "edge_HEPBURN SHIRE_CENTRAL GOLDFIELDS SHIRE_time_3",
        "name" : "edge_HEPBURN SHIRE_CENTRAL GOLDFIELDS SHIRE_time_3",
        "SUID" : 315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "218",
        "source" : "109",
        "target" : "135",
        "shared_name" : "edge_HEPBURN SHIRE_MACEDON RANGES SHIRE_time_1",
        "name" : "edge_HEPBURN SHIRE_MACEDON RANGES SHIRE_time_1",
        "SUID" : 218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "217",
        "source" : "109",
        "target" : "136",
        "shared_name" : "edge_HEPBURN SHIRE_CENTRAL GOLDFIELDS SHIRE_time_1",
        "name" : "edge_HEPBURN SHIRE_CENTRAL GOLDFIELDS SHIRE_time_1",
        "SUID" : 217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "167",
        "source" : "109",
        "target" : "136",
        "shared_name" : "edge_HEPBURN SHIRE_CENTRAL GOLDFIELDS SHIRE_time_0",
        "distance" : 0.412986054432,
        "name" : "edge_HEPBURN SHIRE_CENTRAL GOLDFIELDS SHIRE_time_0",
        "weight" : 0.914721259422,
        "SUID" : 167,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "366",
        "source" : "108",
        "target" : "126",
        "shared_name" : "edge_NORTHERN GRAMPIANS SHIRE_PYRENEES SHIRE_time_4",
        "name" : "edge_NORTHERN GRAMPIANS SHIRE_PYRENEES SHIRE_time_4",
        "SUID" : 366,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "314",
        "source" : "108",
        "target" : "136",
        "shared_name" : "edge_NORTHERN GRAMPIANS SHIRE_CENTRAL GOLDFIELDS SHIRE_time_3",
        "name" : "edge_NORTHERN GRAMPIANS SHIRE_CENTRAL GOLDFIELDS SHIRE_time_3",
        "SUID" : 314,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "267",
        "source" : "108",
        "target" : "136",
        "shared_name" : "edge_NORTHERN GRAMPIANS SHIRE_CENTRAL GOLDFIELDS SHIRE_time_2",
        "name" : "edge_NORTHERN GRAMPIANS SHIRE_CENTRAL GOLDFIELDS SHIRE_time_2",
        "SUID" : 267,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "source" : "108",
        "target" : "126",
        "shared_name" : "edge_NORTHERN GRAMPIANS SHIRE_PYRENEES SHIRE_time_1",
        "name" : "edge_NORTHERN GRAMPIANS SHIRE_PYRENEES SHIRE_time_1",
        "SUID" : 216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "166",
        "source" : "108",
        "target" : "136",
        "shared_name" : "edge_NORTHERN GRAMPIANS SHIRE_CENTRAL GOLDFIELDS SHIRE_time_0",
        "distance" : 0.50879639088,
        "name" : "edge_NORTHERN GRAMPIANS SHIRE_CENTRAL GOLDFIELDS SHIRE_time_0",
        "weight" : 0.870563116314,
        "SUID" : 166,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "source" : "105",
        "target" : "115",
        "shared_name" : "edge_GREATER BENDIGO CITY_CAMPASPE SHIRE_time_4",
        "name" : "edge_GREATER BENDIGO CITY_CAMPASPE SHIRE_time_4",
        "SUID" : 365,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "313",
        "source" : "105",
        "target" : "115",
        "shared_name" : "edge_GREATER BENDIGO CITY_CAMPASPE SHIRE_time_3",
        "name" : "edge_GREATER BENDIGO CITY_CAMPASPE SHIRE_time_3",
        "SUID" : 313,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "source" : "105",
        "target" : "115",
        "shared_name" : "edge_GREATER BENDIGO CITY_CAMPASPE SHIRE_time_2",
        "name" : "edge_GREATER BENDIGO CITY_CAMPASPE SHIRE_time_2",
        "SUID" : 266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "215",
        "source" : "105",
        "target" : "115",
        "shared_name" : "edge_GREATER BENDIGO CITY_CAMPASPE SHIRE_time_1",
        "name" : "edge_GREATER BENDIGO CITY_CAMPASPE SHIRE_time_1",
        "SUID" : 215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "165",
        "source" : "105",
        "target" : "115",
        "shared_name" : "edge_GREATER BENDIGO CITY_CAMPASPE SHIRE_time_0",
        "distance" : 0.5175713091,
        "name" : "edge_GREATER BENDIGO CITY_CAMPASPE SHIRE_time_0",
        "weight" : 0.866059969998,
        "SUID" : 165,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "364",
        "source" : "104",
        "target" : "131",
        "shared_name" : "edge_STRATHBOGIE SHIRE_GREATER SHEPPARTON CITY_time_4",
        "name" : "edge_STRATHBOGIE SHIRE_GREATER SHEPPARTON CITY_time_4",
        "SUID" : 364,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "source" : "104",
        "target" : "115",
        "shared_name" : "edge_STRATHBOGIE SHIRE_CAMPASPE SHIRE_time_4",
        "name" : "edge_STRATHBOGIE SHIRE_CAMPASPE SHIRE_time_4",
        "SUID" : 363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "362",
        "source" : "104",
        "target" : "129",
        "shared_name" : "edge_STRATHBOGIE SHIRE_MURRINDINDI SHIRE_time_4",
        "name" : "edge_STRATHBOGIE SHIRE_MURRINDINDI SHIRE_time_4",
        "SUID" : 362,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "312",
        "source" : "104",
        "target" : "131",
        "shared_name" : "edge_STRATHBOGIE SHIRE_GREATER SHEPPARTON CITY_time_3",
        "name" : "edge_STRATHBOGIE SHIRE_GREATER SHEPPARTON CITY_time_3",
        "SUID" : 312,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "311",
        "source" : "104",
        "target" : "129",
        "shared_name" : "edge_STRATHBOGIE SHIRE_MURRINDINDI SHIRE_time_3",
        "name" : "edge_STRATHBOGIE SHIRE_MURRINDINDI SHIRE_time_3",
        "SUID" : 311,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "265",
        "source" : "104",
        "target" : "131",
        "shared_name" : "edge_STRATHBOGIE SHIRE_GREATER SHEPPARTON CITY_time_2",
        "name" : "edge_STRATHBOGIE SHIRE_GREATER SHEPPARTON CITY_time_2",
        "SUID" : 265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "source" : "104",
        "target" : "131",
        "shared_name" : "edge_STRATHBOGIE SHIRE_GREATER SHEPPARTON CITY_time_1",
        "name" : "edge_STRATHBOGIE SHIRE_GREATER SHEPPARTON CITY_time_1",
        "SUID" : 214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "164",
        "source" : "104",
        "target" : "131",
        "shared_name" : "edge_STRATHBOGIE SHIRE_GREATER SHEPPARTON CITY_time_0",
        "distance" : 0.260251383661,
        "name" : "edge_STRATHBOGIE SHIRE_GREATER SHEPPARTON CITY_time_0",
        "weight" : 0.966134608651,
        "SUID" : 164,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "264",
        "source" : "103",
        "target" : "128",
        "shared_name" : "edge_WANGARATTA RURAL CITY_ALPINE SHIRE_time_2",
        "name" : "edge_WANGARATTA RURAL CITY_ALPINE SHIRE_time_2",
        "SUID" : 264,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "source" : "102",
        "target" : "116",
        "shared_name" : "edge_GOLDEN PLAINS SHIRE_MOORABOOL SHIRE_time_4",
        "name" : "edge_GOLDEN PLAINS SHIRE_MOORABOOL SHIRE_time_4",
        "SUID" : 361,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "310",
        "source" : "102",
        "target" : "116",
        "shared_name" : "edge_GOLDEN PLAINS SHIRE_MOORABOOL SHIRE_time_3",
        "name" : "edge_GOLDEN PLAINS SHIRE_MOORABOOL SHIRE_time_3",
        "SUID" : 310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "309",
        "source" : "102",
        "target" : "114",
        "shared_name" : "edge_GOLDEN PLAINS SHIRE_CORANGAMITE SHIRE_time_3",
        "name" : "edge_GOLDEN PLAINS SHIRE_CORANGAMITE SHIRE_time_3",
        "SUID" : 309,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "263",
        "source" : "102",
        "target" : "116",
        "shared_name" : "edge_GOLDEN PLAINS SHIRE_MOORABOOL SHIRE_time_2",
        "name" : "edge_GOLDEN PLAINS SHIRE_MOORABOOL SHIRE_time_2",
        "SUID" : 263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "262",
        "source" : "102",
        "target" : "114",
        "shared_name" : "edge_GOLDEN PLAINS SHIRE_CORANGAMITE SHIRE_time_2",
        "name" : "edge_GOLDEN PLAINS SHIRE_CORANGAMITE SHIRE_time_2",
        "SUID" : 262,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "213",
        "source" : "102",
        "target" : "116",
        "shared_name" : "edge_GOLDEN PLAINS SHIRE_MOORABOOL SHIRE_time_1",
        "name" : "edge_GOLDEN PLAINS SHIRE_MOORABOOL SHIRE_time_1",
        "SUID" : 213,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "163",
        "source" : "102",
        "target" : "116",
        "shared_name" : "edge_GOLDEN PLAINS SHIRE_MOORABOOL SHIRE_time_0",
        "distance" : 0.565317269012,
        "name" : "edge_GOLDEN PLAINS SHIRE_MOORABOOL SHIRE_time_0",
        "weight" : 0.840208192678,
        "SUID" : 163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "162",
        "source" : "102",
        "target" : "114",
        "shared_name" : "edge_GOLDEN PLAINS SHIRE_CORANGAMITE SHIRE_time_0",
        "distance" : 0.451632341472,
        "name" : "edge_GOLDEN PLAINS SHIRE_CORANGAMITE SHIRE_time_0",
        "weight" : 0.898014114068,
        "SUID" : 162,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "360",
        "source" : "101",
        "target" : "105",
        "shared_name" : "edge_MOUNT ALEXANDER SHIRE_GREATER BENDIGO CITY_time_4",
        "name" : "edge_MOUNT ALEXANDER SHIRE_GREATER BENDIGO CITY_time_4",
        "SUID" : 360,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "source" : "101",
        "target" : "109",
        "shared_name" : "edge_MOUNT ALEXANDER SHIRE_HEPBURN SHIRE_time_4",
        "name" : "edge_MOUNT ALEXANDER SHIRE_HEPBURN SHIRE_time_4",
        "SUID" : 359,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "source" : "101",
        "target" : "105",
        "shared_name" : "edge_MOUNT ALEXANDER SHIRE_GREATER BENDIGO CITY_time_3",
        "name" : "edge_MOUNT ALEXANDER SHIRE_GREATER BENDIGO CITY_time_3",
        "SUID" : 308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "307",
        "source" : "101",
        "target" : "109",
        "shared_name" : "edge_MOUNT ALEXANDER SHIRE_HEPBURN SHIRE_time_3",
        "name" : "edge_MOUNT ALEXANDER SHIRE_HEPBURN SHIRE_time_3",
        "SUID" : 307,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "261",
        "source" : "101",
        "target" : "105",
        "shared_name" : "edge_MOUNT ALEXANDER SHIRE_GREATER BENDIGO CITY_time_2",
        "name" : "edge_MOUNT ALEXANDER SHIRE_GREATER BENDIGO CITY_time_2",
        "SUID" : 261,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "source" : "101",
        "target" : "135",
        "shared_name" : "edge_MOUNT ALEXANDER SHIRE_MACEDON RANGES SHIRE_time_2",
        "name" : "edge_MOUNT ALEXANDER SHIRE_MACEDON RANGES SHIRE_time_2",
        "SUID" : 260,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "259",
        "source" : "101",
        "target" : "109",
        "shared_name" : "edge_MOUNT ALEXANDER SHIRE_HEPBURN SHIRE_time_2",
        "name" : "edge_MOUNT ALEXANDER SHIRE_HEPBURN SHIRE_time_2",
        "SUID" : 259,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "258",
        "source" : "101",
        "target" : "136",
        "shared_name" : "edge_MOUNT ALEXANDER SHIRE_CENTRAL GOLDFIELDS SHIRE_time_2",
        "name" : "edge_MOUNT ALEXANDER SHIRE_CENTRAL GOLDFIELDS SHIRE_time_2",
        "SUID" : 258,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "212",
        "source" : "101",
        "target" : "105",
        "shared_name" : "edge_MOUNT ALEXANDER SHIRE_GREATER BENDIGO CITY_time_1",
        "name" : "edge_MOUNT ALEXANDER SHIRE_GREATER BENDIGO CITY_time_1",
        "SUID" : 212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "211",
        "source" : "101",
        "target" : "109",
        "shared_name" : "edge_MOUNT ALEXANDER SHIRE_HEPBURN SHIRE_time_1",
        "name" : "edge_MOUNT ALEXANDER SHIRE_HEPBURN SHIRE_time_1",
        "SUID" : 211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "161",
        "source" : "101",
        "target" : "105",
        "shared_name" : "edge_MOUNT ALEXANDER SHIRE_GREATER BENDIGO CITY_time_0",
        "distance" : 0.332711415289,
        "name" : "edge_MOUNT ALEXANDER SHIRE_GREATER BENDIGO CITY_time_0",
        "weight" : 0.944651557068,
        "SUID" : 161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "160",
        "source" : "101",
        "target" : "109",
        "shared_name" : "edge_MOUNT ALEXANDER SHIRE_HEPBURN SHIRE_time_0",
        "distance" : 0.33087015776,
        "name" : "edge_MOUNT ALEXANDER SHIRE_HEPBURN SHIRE_time_0",
        "weight" : 0.945262469352,
        "SUID" : 160,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "159",
        "source" : "101",
        "target" : "135",
        "shared_name" : "edge_MOUNT ALEXANDER SHIRE_MACEDON RANGES SHIRE_time_0",
        "distance" : 0.430378758682,
        "name" : "edge_MOUNT ALEXANDER SHIRE_MACEDON RANGES SHIRE_time_0",
        "weight" : 0.907387062038,
        "SUID" : 159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "358",
        "source" : "100",
        "target" : "133",
        "shared_name" : "edge_SURF COAST SHIRE_MORNINGTON PENINSULA SHIRE_time_4",
        "name" : "edge_SURF COAST SHIRE_MORNINGTON PENINSULA SHIRE_time_4",
        "SUID" : 358,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "357",
        "source" : "100",
        "target" : "122",
        "shared_name" : "edge_SURF COAST SHIRE_CARDINIA SHIRE_time_4",
        "name" : "edge_SURF COAST SHIRE_CARDINIA SHIRE_time_4",
        "SUID" : 357,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "source" : "100",
        "target" : "112",
        "shared_name" : "edge_SURF COAST SHIRE_COLAC OTWAY SHIRE_time_4",
        "name" : "edge_SURF COAST SHIRE_COLAC OTWAY SHIRE_time_4",
        "SUID" : 356,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "355",
        "source" : "100",
        "target" : "102",
        "shared_name" : "edge_SURF COAST SHIRE_GOLDEN PLAINS SHIRE_time_4",
        "name" : "edge_SURF COAST SHIRE_GOLDEN PLAINS SHIRE_time_4",
        "SUID" : 355,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "306",
        "source" : "100",
        "target" : "102",
        "shared_name" : "edge_SURF COAST SHIRE_GOLDEN PLAINS SHIRE_time_3",
        "name" : "edge_SURF COAST SHIRE_GOLDEN PLAINS SHIRE_time_3",
        "SUID" : 306,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "source" : "100",
        "target" : "122",
        "shared_name" : "edge_SURF COAST SHIRE_CARDINIA SHIRE_time_2",
        "name" : "edge_SURF COAST SHIRE_CARDINIA SHIRE_time_2",
        "SUID" : 257,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "256",
        "source" : "100",
        "target" : "102",
        "shared_name" : "edge_SURF COAST SHIRE_GOLDEN PLAINS SHIRE_time_2",
        "name" : "edge_SURF COAST SHIRE_GOLDEN PLAINS SHIRE_time_2",
        "SUID" : 256,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "210",
        "source" : "100",
        "target" : "112",
        "shared_name" : "edge_SURF COAST SHIRE_COLAC OTWAY SHIRE_time_1",
        "name" : "edge_SURF COAST SHIRE_COLAC OTWAY SHIRE_time_1",
        "SUID" : 210,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "209",
        "source" : "100",
        "target" : "102",
        "shared_name" : "edge_SURF COAST SHIRE_GOLDEN PLAINS SHIRE_time_1",
        "name" : "edge_SURF COAST SHIRE_GOLDEN PLAINS SHIRE_time_1",
        "SUID" : 209,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "158",
        "source" : "100",
        "target" : "122",
        "shared_name" : "edge_SURF COAST SHIRE_CARDINIA SHIRE_time_0",
        "distance" : 0.605669906185,
        "name" : "edge_SURF COAST SHIRE_CARDINIA SHIRE_time_0",
        "weight" : 0.816581982371,
        "SUID" : 158,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "157",
        "source" : "100",
        "target" : "102",
        "shared_name" : "edge_SURF COAST SHIRE_GOLDEN PLAINS SHIRE_time_0",
        "distance" : 0.369097830574,
        "name" : "edge_SURF COAST SHIRE_GOLDEN PLAINS SHIRE_time_0",
        "weight" : 0.931883395733,
        "SUID" : 157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "354",
        "source" : "99",
        "target" : "131",
        "shared_name" : "edge_BENALLA RURAL CITY_GREATER SHEPPARTON CITY_time_4",
        "name" : "edge_BENALLA RURAL CITY_GREATER SHEPPARTON CITY_time_4",
        "SUID" : 354,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "353",
        "source" : "99",
        "target" : "103",
        "shared_name" : "edge_BENALLA RURAL CITY_WANGARATTA RURAL CITY_time_4",
        "name" : "edge_BENALLA RURAL CITY_WANGARATTA RURAL CITY_time_4",
        "SUID" : 353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "305",
        "source" : "99",
        "target" : "103",
        "shared_name" : "edge_BENALLA RURAL CITY_WANGARATTA RURAL CITY_time_3",
        "name" : "edge_BENALLA RURAL CITY_WANGARATTA RURAL CITY_time_3",
        "SUID" : 305,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "255",
        "source" : "99",
        "target" : "131",
        "shared_name" : "edge_BENALLA RURAL CITY_GREATER SHEPPARTON CITY_time_2",
        "name" : "edge_BENALLA RURAL CITY_GREATER SHEPPARTON CITY_time_2",
        "SUID" : 255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "source" : "99",
        "target" : "103",
        "shared_name" : "edge_BENALLA RURAL CITY_WANGARATTA RURAL CITY_time_2",
        "name" : "edge_BENALLA RURAL CITY_WANGARATTA RURAL CITY_time_2",
        "SUID" : 254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "source" : "99",
        "target" : "131",
        "shared_name" : "edge_BENALLA RURAL CITY_GREATER SHEPPARTON CITY_time_1",
        "name" : "edge_BENALLA RURAL CITY_GREATER SHEPPARTON CITY_time_1",
        "SUID" : 208,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "207",
        "source" : "99",
        "target" : "103",
        "shared_name" : "edge_BENALLA RURAL CITY_WANGARATTA RURAL CITY_time_1",
        "name" : "edge_BENALLA RURAL CITY_WANGARATTA RURAL CITY_time_1",
        "SUID" : 207,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "156",
        "source" : "99",
        "target" : "131",
        "shared_name" : "edge_BENALLA RURAL CITY_GREATER SHEPPARTON CITY_time_0",
        "distance" : 0.470113619887,
        "name" : "edge_BENALLA RURAL CITY_GREATER SHEPPARTON CITY_time_0",
        "weight" : 0.889496592198,
        "SUID" : 156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "155",
        "source" : "99",
        "target" : "103",
        "shared_name" : "edge_BENALLA RURAL CITY_WANGARATTA RURAL CITY_time_0",
        "distance" : 0.551178594008,
        "name" : "edge_BENALLA RURAL CITY_WANGARATTA RURAL CITY_time_0",
        "weight" : 0.848101078754,
        "SUID" : 155,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "352",
        "source" : "98",
        "target" : "123",
        "shared_name" : "edge_BASS COAST SHIRE_SOUTH GIPPSLAND SHIRE_time_4",
        "name" : "edge_BASS COAST SHIRE_SOUTH GIPPSLAND SHIRE_time_4",
        "SUID" : 352,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "source" : "98",
        "target" : "133",
        "shared_name" : "edge_BASS COAST SHIRE_MORNINGTON PENINSULA SHIRE_time_4",
        "name" : "edge_BASS COAST SHIRE_MORNINGTON PENINSULA SHIRE_time_4",
        "SUID" : 351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "304",
        "source" : "98",
        "target" : "123",
        "shared_name" : "edge_BASS COAST SHIRE_SOUTH GIPPSLAND SHIRE_time_3",
        "name" : "edge_BASS COAST SHIRE_SOUTH GIPPSLAND SHIRE_time_3",
        "SUID" : 304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "303",
        "source" : "98",
        "target" : "133",
        "shared_name" : "edge_BASS COAST SHIRE_MORNINGTON PENINSULA SHIRE_time_3",
        "name" : "edge_BASS COAST SHIRE_MORNINGTON PENINSULA SHIRE_time_3",
        "SUID" : 303,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "253",
        "source" : "98",
        "target" : "123",
        "shared_name" : "edge_BASS COAST SHIRE_SOUTH GIPPSLAND SHIRE_time_2",
        "name" : "edge_BASS COAST SHIRE_SOUTH GIPPSLAND SHIRE_time_2",
        "SUID" : 253,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "252",
        "source" : "98",
        "target" : "133",
        "shared_name" : "edge_BASS COAST SHIRE_MORNINGTON PENINSULA SHIRE_time_2",
        "name" : "edge_BASS COAST SHIRE_MORNINGTON PENINSULA SHIRE_time_2",
        "SUID" : 252,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "source" : "98",
        "target" : "123",
        "shared_name" : "edge_BASS COAST SHIRE_SOUTH GIPPSLAND SHIRE_time_1",
        "name" : "edge_BASS COAST SHIRE_SOUTH GIPPSLAND SHIRE_time_1",
        "SUID" : 206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "205",
        "source" : "98",
        "target" : "133",
        "shared_name" : "edge_BASS COAST SHIRE_MORNINGTON PENINSULA SHIRE_time_1",
        "name" : "edge_BASS COAST SHIRE_MORNINGTON PENINSULA SHIRE_time_1",
        "SUID" : 205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "154",
        "source" : "98",
        "target" : "123",
        "shared_name" : "edge_BASS COAST SHIRE_SOUTH GIPPSLAND SHIRE_time_0",
        "distance" : 0.313875038008,
        "name" : "edge_BASS COAST SHIRE_SOUTH GIPPSLAND SHIRE_time_0",
        "weight" : 0.950741230258,
        "SUID" : 154,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "153",
        "source" : "98",
        "target" : "133",
        "shared_name" : "edge_BASS COAST SHIRE_MORNINGTON PENINSULA SHIRE_time_0",
        "distance" : 0.536730990056,
        "name" : "edge_BASS COAST SHIRE_MORNINGTON PENINSULA SHIRE_time_0",
        "weight" : 0.855959922157,
        "SUID" : 153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "350",
        "source" : "97",
        "target" : "131",
        "shared_name" : "edge_MOIRA SHIRE_GREATER SHEPPARTON CITY_time_4",
        "name" : "edge_MOIRA SHIRE_GREATER SHEPPARTON CITY_time_4",
        "SUID" : 350,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "source" : "97",
        "target" : "131",
        "shared_name" : "edge_MOIRA SHIRE_GREATER SHEPPARTON CITY_time_3",
        "name" : "edge_MOIRA SHIRE_GREATER SHEPPARTON CITY_time_3",
        "SUID" : 302,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "301",
        "source" : "97",
        "target" : "99",
        "shared_name" : "edge_MOIRA SHIRE_BENALLA RURAL CITY_time_3",
        "name" : "edge_MOIRA SHIRE_BENALLA RURAL CITY_time_3",
        "SUID" : 301,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "251",
        "source" : "97",
        "target" : "131",
        "shared_name" : "edge_MOIRA SHIRE_GREATER SHEPPARTON CITY_time_2",
        "name" : "edge_MOIRA SHIRE_GREATER SHEPPARTON CITY_time_2",
        "SUID" : 251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "204",
        "source" : "97",
        "target" : "131",
        "shared_name" : "edge_MOIRA SHIRE_GREATER SHEPPARTON CITY_time_1",
        "name" : "edge_MOIRA SHIRE_GREATER SHEPPARTON CITY_time_1",
        "SUID" : 204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "152",
        "source" : "97",
        "target" : "131",
        "shared_name" : "edge_MOIRA SHIRE_GREATER SHEPPARTON CITY_time_0",
        "distance" : 0.360143811396,
        "name" : "edge_MOIRA SHIRE_GREATER SHEPPARTON CITY_time_0",
        "weight" : 0.935148217557,
        "SUID" : 152,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "349",
        "source" : "96",
        "target" : "121",
        "shared_name" : "edge_YARRIAMBIACK SHIRE_MILDURA RURAL CITY_time_4",
        "name" : "edge_YARRIAMBIACK SHIRE_MILDURA RURAL CITY_time_4",
        "SUID" : 349,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "348",
        "source" : "96",
        "target" : "108",
        "shared_name" : "edge_YARRIAMBIACK SHIRE_NORTHERN GRAMPIANS SHIRE_time_4",
        "name" : "edge_YARRIAMBIACK SHIRE_NORTHERN GRAMPIANS SHIRE_time_4",
        "SUID" : 348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "source" : "96",
        "target" : "106",
        "shared_name" : "edge_YARRIAMBIACK SHIRE_BULOKE SHIRE_time_4",
        "name" : "edge_YARRIAMBIACK SHIRE_BULOKE SHIRE_time_4",
        "SUID" : 347,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "300",
        "source" : "96",
        "target" : "121",
        "shared_name" : "edge_YARRIAMBIACK SHIRE_MILDURA RURAL CITY_time_3",
        "name" : "edge_YARRIAMBIACK SHIRE_MILDURA RURAL CITY_time_3",
        "SUID" : 300,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "299",
        "source" : "96",
        "target" : "108",
        "shared_name" : "edge_YARRIAMBIACK SHIRE_NORTHERN GRAMPIANS SHIRE_time_3",
        "name" : "edge_YARRIAMBIACK SHIRE_NORTHERN GRAMPIANS SHIRE_time_3",
        "SUID" : 299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "source" : "96",
        "target" : "106",
        "shared_name" : "edge_YARRIAMBIACK SHIRE_BULOKE SHIRE_time_3",
        "name" : "edge_YARRIAMBIACK SHIRE_BULOKE SHIRE_time_3",
        "SUID" : 298,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "250",
        "source" : "96",
        "target" : "108",
        "shared_name" : "edge_YARRIAMBIACK SHIRE_NORTHERN GRAMPIANS SHIRE_time_2",
        "name" : "edge_YARRIAMBIACK SHIRE_NORTHERN GRAMPIANS SHIRE_time_2",
        "SUID" : 250,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "249",
        "source" : "96",
        "target" : "106",
        "shared_name" : "edge_YARRIAMBIACK SHIRE_BULOKE SHIRE_time_2",
        "name" : "edge_YARRIAMBIACK SHIRE_BULOKE SHIRE_time_2",
        "SUID" : 249,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "203",
        "source" : "96",
        "target" : "121",
        "shared_name" : "edge_YARRIAMBIACK SHIRE_MILDURA RURAL CITY_time_1",
        "name" : "edge_YARRIAMBIACK SHIRE_MILDURA RURAL CITY_time_1",
        "SUID" : 203,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "source" : "96",
        "target" : "106",
        "shared_name" : "edge_YARRIAMBIACK SHIRE_BULOKE SHIRE_time_1",
        "name" : "edge_YARRIAMBIACK SHIRE_BULOKE SHIRE_time_1",
        "SUID" : 202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "151",
        "source" : "96",
        "target" : "106",
        "shared_name" : "edge_YARRIAMBIACK SHIRE_BULOKE SHIRE_time_0",
        "distance" : 0.300019445844,
        "name" : "edge_YARRIAMBIACK SHIRE_BULOKE SHIRE_time_0",
        "weight" : 0.954994166058,
        "SUID" : 151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "346",
        "source" : "95",
        "target" : "127",
        "shared_name" : "edge_INDIGO SHIRE_WODONGA CITY_time_4",
        "name" : "edge_INDIGO SHIRE_WODONGA CITY_time_4",
        "SUID" : 346,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "345",
        "source" : "95",
        "target" : "103",
        "shared_name" : "edge_INDIGO SHIRE_WANGARATTA RURAL CITY_time_4",
        "name" : "edge_INDIGO SHIRE_WANGARATTA RURAL CITY_time_4",
        "SUID" : 345,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "297",
        "source" : "95",
        "target" : "127",
        "shared_name" : "edge_INDIGO SHIRE_WODONGA CITY_time_3",
        "name" : "edge_INDIGO SHIRE_WODONGA CITY_time_3",
        "SUID" : 297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "source" : "95",
        "target" : "103",
        "shared_name" : "edge_INDIGO SHIRE_WANGARATTA RURAL CITY_time_3",
        "name" : "edge_INDIGO SHIRE_WANGARATTA RURAL CITY_time_3",
        "SUID" : 296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "source" : "95",
        "target" : "127",
        "shared_name" : "edge_INDIGO SHIRE_WODONGA CITY_time_2",
        "name" : "edge_INDIGO SHIRE_WODONGA CITY_time_2",
        "SUID" : 248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "247",
        "source" : "95",
        "target" : "103",
        "shared_name" : "edge_INDIGO SHIRE_WANGARATTA RURAL CITY_time_2",
        "name" : "edge_INDIGO SHIRE_WANGARATTA RURAL CITY_time_2",
        "SUID" : 247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "201",
        "source" : "95",
        "target" : "127",
        "shared_name" : "edge_INDIGO SHIRE_WODONGA CITY_time_1",
        "name" : "edge_INDIGO SHIRE_WODONGA CITY_time_1",
        "SUID" : 201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "source" : "95",
        "target" : "103",
        "shared_name" : "edge_INDIGO SHIRE_WANGARATTA RURAL CITY_time_1",
        "name" : "edge_INDIGO SHIRE_WANGARATTA RURAL CITY_time_1",
        "SUID" : 200,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "150",
        "source" : "95",
        "target" : "127",
        "shared_name" : "edge_INDIGO SHIRE_WODONGA CITY_time_0",
        "distance" : 0.385728019761,
        "name" : "edge_INDIGO SHIRE_WODONGA CITY_time_0",
        "weight" : 0.925606947386,
        "SUID" : 150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "149",
        "source" : "95",
        "target" : "103",
        "shared_name" : "edge_INDIGO SHIRE_WANGARATTA RURAL CITY_time_0",
        "distance" : 0.360438134833,
        "name" : "edge_INDIGO SHIRE_WANGARATTA RURAL CITY_time_0",
        "weight" : 0.935042175479,
        "SUID" : 149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "344",
        "source" : "94",
        "target" : "96",
        "shared_name" : "edge_HINDMARSH SHIRE_YARRIAMBIACK SHIRE_time_4",
        "name" : "edge_HINDMARSH SHIRE_YARRIAMBIACK SHIRE_time_4",
        "SUID" : 344,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "295",
        "source" : "94",
        "target" : "96",
        "shared_name" : "edge_HINDMARSH SHIRE_YARRIAMBIACK SHIRE_time_3",
        "name" : "edge_HINDMARSH SHIRE_YARRIAMBIACK SHIRE_time_3",
        "SUID" : 295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "246",
        "source" : "94",
        "target" : "96",
        "shared_name" : "edge_HINDMARSH SHIRE_YARRIAMBIACK SHIRE_time_2",
        "name" : "edge_HINDMARSH SHIRE_YARRIAMBIACK SHIRE_time_2",
        "SUID" : 246,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "199",
        "source" : "94",
        "target" : "96",
        "shared_name" : "edge_HINDMARSH SHIRE_YARRIAMBIACK SHIRE_time_1",
        "name" : "edge_HINDMARSH SHIRE_YARRIAMBIACK SHIRE_time_1",
        "SUID" : 199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "148",
        "source" : "94",
        "target" : "96",
        "shared_name" : "edge_HINDMARSH SHIRE_YARRIAMBIACK SHIRE_time_0",
        "distance" : 0.397211368168,
        "name" : "edge_HINDMARSH SHIRE_YARRIAMBIACK SHIRE_time_0",
        "weight" : 0.921111564499,
        "SUID" : 148,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "343",
        "source" : "93",
        "target" : "111",
        "shared_name" : "edge_SOUTHERN GRAMPIANS SHIRE_GLENELG SHIRE_time_4",
        "name" : "edge_SOUTHERN GRAMPIANS SHIRE_GLENELG SHIRE_time_4",
        "SUID" : 343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "342",
        "source" : "93",
        "target" : "117",
        "shared_name" : "edge_SOUTHERN GRAMPIANS SHIRE_ARARAT RURAL CITY_time_4",
        "name" : "edge_SOUTHERN GRAMPIANS SHIRE_ARARAT RURAL CITY_time_4",
        "SUID" : 342,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "source" : "93",
        "target" : "111",
        "shared_name" : "edge_SOUTHERN GRAMPIANS SHIRE_GLENELG SHIRE_time_3",
        "name" : "edge_SOUTHERN GRAMPIANS SHIRE_GLENELG SHIRE_time_3",
        "SUID" : 294,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "293",
        "source" : "93",
        "target" : "117",
        "shared_name" : "edge_SOUTHERN GRAMPIANS SHIRE_ARARAT RURAL CITY_time_3",
        "name" : "edge_SOUTHERN GRAMPIANS SHIRE_ARARAT RURAL CITY_time_3",
        "SUID" : 293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "source" : "93",
        "target" : "111",
        "shared_name" : "edge_SOUTHERN GRAMPIANS SHIRE_GLENELG SHIRE_time_2",
        "name" : "edge_SOUTHERN GRAMPIANS SHIRE_GLENELG SHIRE_time_2",
        "SUID" : 245,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "244",
        "source" : "93",
        "target" : "117",
        "shared_name" : "edge_SOUTHERN GRAMPIANS SHIRE_ARARAT RURAL CITY_time_2",
        "name" : "edge_SOUTHERN GRAMPIANS SHIRE_ARARAT RURAL CITY_time_2",
        "SUID" : 244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "198",
        "source" : "93",
        "target" : "111",
        "shared_name" : "edge_SOUTHERN GRAMPIANS SHIRE_GLENELG SHIRE_time_1",
        "name" : "edge_SOUTHERN GRAMPIANS SHIRE_GLENELG SHIRE_time_1",
        "SUID" : 198,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "197",
        "source" : "93",
        "target" : "117",
        "shared_name" : "edge_SOUTHERN GRAMPIANS SHIRE_ARARAT RURAL CITY_time_1",
        "name" : "edge_SOUTHERN GRAMPIANS SHIRE_ARARAT RURAL CITY_time_1",
        "SUID" : 197,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "196",
        "source" : "93",
        "target" : "119",
        "shared_name" : "edge_SOUTHERN GRAMPIANS SHIRE_MOYNE SHIRE_time_1",
        "name" : "edge_SOUTHERN GRAMPIANS SHIRE_MOYNE SHIRE_time_1",
        "SUID" : 196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "147",
        "source" : "93",
        "target" : "111",
        "shared_name" : "edge_SOUTHERN GRAMPIANS SHIRE_GLENELG SHIRE_time_0",
        "distance" : 0.562624183938,
        "name" : "edge_SOUTHERN GRAMPIANS SHIRE_GLENELG SHIRE_time_0",
        "weight" : 0.841727013824,
        "SUID" : 147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "146",
        "source" : "93",
        "target" : "117",
        "shared_name" : "edge_SOUTHERN GRAMPIANS SHIRE_ARARAT RURAL CITY_time_0",
        "distance" : 0.457452659912,
        "name" : "edge_SOUTHERN GRAMPIANS SHIRE_ARARAT RURAL CITY_time_0",
        "weight" : 0.89536853197,
        "SUID" : 146,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "341",
        "source" : "92",
        "target" : "132",
        "shared_name" : "edge_LODDON SHIRE_GANNAWARRA SHIRE_time_4",
        "name" : "edge_LODDON SHIRE_GANNAWARRA SHIRE_time_4",
        "SUID" : 341,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "340",
        "source" : "92",
        "target" : "106",
        "shared_name" : "edge_LODDON SHIRE_BULOKE SHIRE_time_4",
        "name" : "edge_LODDON SHIRE_BULOKE SHIRE_time_4",
        "SUID" : 340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "source" : "92",
        "target" : "132",
        "shared_name" : "edge_LODDON SHIRE_GANNAWARRA SHIRE_time_3",
        "name" : "edge_LODDON SHIRE_GANNAWARRA SHIRE_time_3",
        "SUID" : 292,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "291",
        "source" : "92",
        "target" : "106",
        "shared_name" : "edge_LODDON SHIRE_BULOKE SHIRE_time_3",
        "name" : "edge_LODDON SHIRE_BULOKE SHIRE_time_3",
        "SUID" : 291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "243",
        "source" : "92",
        "target" : "132",
        "shared_name" : "edge_LODDON SHIRE_GANNAWARRA SHIRE_time_2",
        "name" : "edge_LODDON SHIRE_GANNAWARRA SHIRE_time_2",
        "SUID" : 243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "source" : "92",
        "target" : "106",
        "shared_name" : "edge_LODDON SHIRE_BULOKE SHIRE_time_2",
        "name" : "edge_LODDON SHIRE_BULOKE SHIRE_time_2",
        "SUID" : 242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "195",
        "source" : "92",
        "target" : "132",
        "shared_name" : "edge_LODDON SHIRE_GANNAWARRA SHIRE_time_1",
        "name" : "edge_LODDON SHIRE_GANNAWARRA SHIRE_time_1",
        "SUID" : 195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "194",
        "source" : "92",
        "target" : "101",
        "shared_name" : "edge_LODDON SHIRE_MOUNT ALEXANDER SHIRE_time_1",
        "name" : "edge_LODDON SHIRE_MOUNT ALEXANDER SHIRE_time_1",
        "SUID" : 194,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "193",
        "source" : "92",
        "target" : "106",
        "shared_name" : "edge_LODDON SHIRE_BULOKE SHIRE_time_1",
        "name" : "edge_LODDON SHIRE_BULOKE SHIRE_time_1",
        "SUID" : 193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "145",
        "source" : "92",
        "target" : "132",
        "shared_name" : "edge_LODDON SHIRE_GANNAWARRA SHIRE_time_0",
        "distance" : 0.323296271182,
        "name" : "edge_LODDON SHIRE_GANNAWARRA SHIRE_time_0",
        "weight" : 0.94773976052,
        "SUID" : 145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "144",
        "source" : "92",
        "target" : "106",
        "shared_name" : "edge_LODDON SHIRE_BULOKE SHIRE_time_0",
        "distance" : 0.432205789234,
        "name" : "edge_LODDON SHIRE_BULOKE SHIRE_time_0",
        "weight" : 0.906599077876,
        "SUID" : 144,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "339",
        "source" : "91",
        "target" : "116",
        "shared_name" : "edge_BALLARAT CITY_MOORABOOL SHIRE_time_4",
        "name" : "edge_BALLARAT CITY_MOORABOOL SHIRE_time_4",
        "SUID" : 339,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "source" : "91",
        "target" : "126",
        "shared_name" : "edge_BALLARAT CITY_PYRENEES SHIRE_time_4",
        "name" : "edge_BALLARAT CITY_PYRENEES SHIRE_time_4",
        "SUID" : 338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "source" : "91",
        "target" : "126",
        "shared_name" : "edge_BALLARAT CITY_PYRENEES SHIRE_time_3",
        "name" : "edge_BALLARAT CITY_PYRENEES SHIRE_time_3",
        "SUID" : 290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "289",
        "source" : "91",
        "target" : "117",
        "shared_name" : "edge_BALLARAT CITY_ARARAT RURAL CITY_time_3",
        "name" : "edge_BALLARAT CITY_ARARAT RURAL CITY_time_3",
        "SUID" : 289,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "241",
        "source" : "91",
        "target" : "126",
        "shared_name" : "edge_BALLARAT CITY_PYRENEES SHIRE_time_2",
        "name" : "edge_BALLARAT CITY_PYRENEES SHIRE_time_2",
        "SUID" : 241,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "240",
        "source" : "91",
        "target" : "117",
        "shared_name" : "edge_BALLARAT CITY_ARARAT RURAL CITY_time_2",
        "name" : "edge_BALLARAT CITY_ARARAT RURAL CITY_time_2",
        "SUID" : 240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "192",
        "source" : "91",
        "target" : "126",
        "shared_name" : "edge_BALLARAT CITY_PYRENEES SHIRE_time_1",
        "name" : "edge_BALLARAT CITY_PYRENEES SHIRE_time_1",
        "SUID" : 192,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "191",
        "source" : "91",
        "target" : "117",
        "shared_name" : "edge_BALLARAT CITY_ARARAT RURAL CITY_time_1",
        "name" : "edge_BALLARAT CITY_ARARAT RURAL CITY_time_1",
        "SUID" : 191,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "143",
        "source" : "91",
        "target" : "116",
        "shared_name" : "edge_BALLARAT CITY_MOORABOOL SHIRE_time_0",
        "distance" : 0.590150860527,
        "name" : "edge_BALLARAT CITY_MOORABOOL SHIRE_time_0",
        "weight" : 0.82586098091,
        "SUID" : 143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "142",
        "source" : "91",
        "target" : "126",
        "shared_name" : "edge_BALLARAT CITY_PYRENEES SHIRE_time_0",
        "distance" : 0.399822252051,
        "name" : "edge_BALLARAT CITY_PYRENEES SHIRE_time_0",
        "weight" : 0.920071083382,
        "SUID" : 142,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "337",
        "source" : "90",
        "target" : "94",
        "shared_name" : "edge_HORSHAM RURAL CITY_HINDMARSH SHIRE_time_4",
        "name" : "edge_HORSHAM RURAL CITY_HINDMARSH SHIRE_time_4",
        "SUID" : 337,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "336",
        "source" : "90",
        "target" : "107",
        "shared_name" : "edge_HORSHAM RURAL CITY_WEST WIMMERA SHIRE_time_4",
        "name" : "edge_HORSHAM RURAL CITY_WEST WIMMERA SHIRE_time_4",
        "SUID" : 336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "source" : "90",
        "target" : "107",
        "shared_name" : "edge_HORSHAM RURAL CITY_WEST WIMMERA SHIRE_time_3",
        "name" : "edge_HORSHAM RURAL CITY_WEST WIMMERA SHIRE_time_3",
        "SUID" : 288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "287",
        "source" : "90",
        "target" : "94",
        "shared_name" : "edge_HORSHAM RURAL CITY_HINDMARSH SHIRE_time_3",
        "name" : "edge_HORSHAM RURAL CITY_HINDMARSH SHIRE_time_3",
        "SUID" : 287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "239",
        "source" : "90",
        "target" : "94",
        "shared_name" : "edge_HORSHAM RURAL CITY_HINDMARSH SHIRE_time_2",
        "name" : "edge_HORSHAM RURAL CITY_HINDMARSH SHIRE_time_2",
        "SUID" : 239,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "238",
        "source" : "90",
        "target" : "107",
        "shared_name" : "edge_HORSHAM RURAL CITY_WEST WIMMERA SHIRE_time_2",
        "name" : "edge_HORSHAM RURAL CITY_WEST WIMMERA SHIRE_time_2",
        "SUID" : 238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "source" : "90",
        "target" : "107",
        "shared_name" : "edge_HORSHAM RURAL CITY_WEST WIMMERA SHIRE_time_1",
        "name" : "edge_HORSHAM RURAL CITY_WEST WIMMERA SHIRE_time_1",
        "SUID" : 190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "189",
        "source" : "90",
        "target" : "94",
        "shared_name" : "edge_HORSHAM RURAL CITY_HINDMARSH SHIRE_time_1",
        "name" : "edge_HORSHAM RURAL CITY_HINDMARSH SHIRE_time_1",
        "SUID" : 189,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "141",
        "source" : "90",
        "target" : "94",
        "shared_name" : "edge_HORSHAM RURAL CITY_HINDMARSH SHIRE_time_0",
        "distance" : 0.507417756903,
        "name" : "edge_HORSHAM RURAL CITY_HINDMARSH SHIRE_time_0",
        "weight" : 0.87126360999,
        "SUID" : 141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "140",
        "source" : "90",
        "target" : "107",
        "shared_name" : "edge_HORSHAM RURAL CITY_WEST WIMMERA SHIRE_time_0",
        "distance" : 0.471839406626,
        "name" : "edge_HORSHAM RURAL CITY_WEST WIMMERA SHIRE_time_0",
        "weight" : 0.888683787177,
        "SUID" : 140,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "335",
        "source" : "89",
        "target" : "119",
        "shared_name" : "edge_WARRNAMBOOL CITY_MOYNE SHIRE_time_4",
        "name" : "edge_WARRNAMBOOL CITY_MOYNE SHIRE_time_4",
        "SUID" : 335,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "286",
        "source" : "89",
        "target" : "119",
        "shared_name" : "edge_WARRNAMBOOL CITY_MOYNE SHIRE_time_3",
        "name" : "edge_WARRNAMBOOL CITY_MOYNE SHIRE_time_3",
        "SUID" : 286,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "237",
        "source" : "89",
        "target" : "119",
        "shared_name" : "edge_WARRNAMBOOL CITY_MOYNE SHIRE_time_2",
        "name" : "edge_WARRNAMBOOL CITY_MOYNE SHIRE_time_2",
        "SUID" : 237,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "188",
        "source" : "89",
        "target" : "119",
        "shared_name" : "edge_WARRNAMBOOL CITY_MOYNE SHIRE_time_1",
        "name" : "edge_WARRNAMBOOL CITY_MOYNE SHIRE_time_1",
        "SUID" : 188,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "139",
        "source" : "89",
        "target" : "119",
        "shared_name" : "edge_WARRNAMBOOL CITY_MOYNE SHIRE_time_0",
        "distance" : 0.449426652721,
        "name" : "edge_WARRNAMBOOL CITY_MOYNE SHIRE_time_0",
        "weight" : 0.899007841912,
        "SUID" : 139,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}